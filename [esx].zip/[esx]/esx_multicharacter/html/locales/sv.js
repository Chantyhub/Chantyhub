const translate = new Object();

translate.name = "Namn";
translate.job = "Jobb";
translate.bank = "Bank";
translate.money = "Kontanter";
translate.gender = "Kön";
translate.dob = "Födelsedatum";
