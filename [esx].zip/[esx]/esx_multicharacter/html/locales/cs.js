const translate = new Object();

translate.name = "Jméno";
translate.job = "Práce";
translate.bank = "Banka";
translate.money = "Peníze";
translate.gender = "Pohlaví";
translate.dob = "Datum narození";
