Locales["sv"] = {
    ["skin_menu"] = "Skin Meny",
    ["use_rotate_view"] = "Använd ~INPUT_FRONTEND_LS~ och ~INPUT_CHARACTER_WHEEL~ för att rotera.",
    ["skin"] = "Ända utseende",
    ["saveskin"] = "Spara",
}
