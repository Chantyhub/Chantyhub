Locales["sr"] = {
    ["skin_menu"] = "Skin Meni",
    ["use_rotate_view"] = "koristi ~INPUT_FRONTEND_LS~ i ~INPUT_CHARACTER_WHEEL~ da rotiras kameru.",
    ["skin"] = "promeni skin",
    ["saveskin"] = "sacuvaj skin u file",
}
