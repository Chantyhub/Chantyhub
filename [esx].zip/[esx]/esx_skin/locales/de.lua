Locales["de"] = {
    ["skin_menu"] = "Skin Menü",
    ["use_rotate_view"] = "Drücke ~INPUT_FRONTEND_LS~ oder ~INPUT_CHARACTER_WHEEL~ um deine Ansicht zu ändern.",
    ["skin"] = "Aussehen ändern",
    ["saveskin"] = "Aussehen abspeichern",
  }