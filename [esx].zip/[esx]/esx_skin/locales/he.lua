Locales["he"] = {
    ["skin_menu"] = "תפריט עור",
    ["use_rotate_view"] = "השתמש ~INPUT_FRONTEND_LS~ ו ~INPUT_CHARACTER_WHEEL~ כדי לסובב את התצוגה.",
    ["skin"] = "שנה עור",
    ["saveskin"] = "שמור עור לקובץ",
}
